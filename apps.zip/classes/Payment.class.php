<?php

class Payment
{
    
    public function paypal()
    {
        
    }
}
