
<form action="" method="post">
    <label for="">Username</label>
    <input type="text" name="address_type"> <br>
    <input type="text" name="city"> <br>
    <input type="text" name="mobile"> <br>
    <input type="hidden" name="user_id" value="1">
    <input type="submit" value="submit" name="submit">
</form>