<?php
import("apps/view/inc/header.php");
?>